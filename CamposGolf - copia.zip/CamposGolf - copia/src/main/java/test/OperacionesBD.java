package test;

import beans.Campo;
import connection.DBConnection;
import java.sql.ResultSet;
import java.sql.Statement;

public class OperacionesBD {
    

    public static void main(String[] args) {
        //listarCampo();
        actualizarCampo(1, "Club de golf Le Florida");

    }

    public static void actualizarCampo(int id, String nombre) {
        DBConnection con = new DBConnection();
        String sql = "UPDATE campo SET nombre = '" + nombre + "'WHERE id = " + id;

        try {
            Statement st = con.getConnection().createStatement();
            st.executeUpdate(sql);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());

        } finally {
            con.desconectar();

        }

    }

    public static void listarCampo() {
        DBConnection con = new DBConnection();
        String sql = "SELECT * FROM campo";

        try {
            Statement st = con.getConnection().createStatement();
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                int id = rs.getInt("id");
                String nombre = rs.getString("nombre");
                String ubicacion = rs.getString("ubicacion");
                int hoyos = rs.getInt("hoyos");
                String estado = rs.getString("estado");
                int yardajeTotal = rs.getInt("yardaje total");
                String clima = rs.getString("clima");
                
                Campo campo = new Campo(id, nombre, ubicacion, hoyos, estado, yardajeTotal, clima);
                System.out.println(campo.toString());
            }

            st.executeQuery(sql);

        } catch (Exception ex) {
            System.out.println(ex.getMessage());

        } finally {
            con.desconectar();

        }

    }
}
