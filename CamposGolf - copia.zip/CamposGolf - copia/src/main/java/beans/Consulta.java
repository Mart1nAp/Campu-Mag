package beans;

import java.sql.Date;

public class Consulta {
    
    private int id;
    private String username;
    private Date fecha;
    private String clima;
    private String ubicacion;

    public Consulta(int id, String username, Date fecha, String clima, String ubicacion) {
        this.id = id;
        this.username = username;
        this.fecha = fecha;
        this.clima = clima;
        this.ubicacion = ubicacion;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getClima() {
        return clima;
    }

    public void setClima(String clima) {
        this.clima = clima;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    @Override
    public String toString() {
        return "Consulta{" + "id=" + id + ", username=" + username + ", fecha=" + fecha + ", clima=" + clima + ", ubicacion=" + ubicacion + '}';
    }
    
    
   
    
}
