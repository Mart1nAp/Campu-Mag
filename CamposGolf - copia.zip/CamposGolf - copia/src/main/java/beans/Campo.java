package beans;

public class Campo {
    private int id;
    private String nombre;
    private String ubicacion;
    private int hoyos;
    private int yardajeTotal;
    private String clima;

    public Campo(int id, String nombre, String ubicacion, int hoyos, int yardajeTotal, String clima) {
        this.id = id;
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.hoyos = hoyos;
        this.yardajeTotal = yardajeTotal;
        this.clima = clima;
    }

    public Campo(int id, String nombre, String ubicacion, int hoyos, String estado, int yardajeTotal, String clima) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public int getHoyos() {
        return hoyos;
    }

    public void setHoyos(int hoyos) {
        this.hoyos = hoyos;
    }

    public int getYardajeTotal() {
        return yardajeTotal;
    }

    public void setYardajeTotal(int yardajeTotal) {
        this.yardajeTotal = yardajeTotal;
    }

    public String getClima() {
        return clima;
    }

    public void setClima(String clima) {
        this.clima = clima;
    }

    @Override
    public String toString() {
        return "Campo{" + "id=" + id + ", nombre=" + nombre + ", ubicacion=" + ubicacion + ", hoyos=" + hoyos + ", yardajeTotal=" + yardajeTotal + ", clima=" + clima + '}';
    }
    
    

    
}
