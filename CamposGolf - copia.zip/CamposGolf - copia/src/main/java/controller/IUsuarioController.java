package controller;

import java.util.Map;

public interface IUsuarioController {

    public String login(String username, String contrasena);


}
